let personagem1, personagem2;
let cenarios = [];
let cenarioAtual = 0;
let textoExplicativo = "Pressione qualquer tecla para mudar de cenário!";
let coresCenarios = [
  [255, 0, 0],    // Cenário 1 (vermelho)
  [0, 255, 0],    // Cenário 2 (verde)
  [0, 0, 255],    // Cenário 3 (azul)
  [255, 255, 0],  // Cenário 4 (amarelo)
  [255, 165, 0]   // Cenário 5 (laranja)
];

function setup() {
  createCanvas(800, 600);

  // Inicialização dos personagens
  personagem1 = new Personagem(100, 300, 'Personagem 1', [255, 0, 0]);
  personagem2 = new Personagem(600, 300, 'Personagem 2', [0, 0, 255]);
}

function draw() {
  // Exibe o cenário atual
  background(coresCenarios[cenarioAtual]);

  // Desenha os personagens
  personagem1.show();
  personagem2.show();

  // Exibe o texto explicativo
  fill(0);
  textSize(20);
  text(textoExplicativo, 50, height - 50);
}

function keyPressed() {
  // Mudar o cenário a cada tecla pressionada
  cenarioAtual = (cenarioAtual + 1) % coresCenarios.length;
  textoExplicativo = "Você mudou de cenário! Pressione novamente para continuar.";
}

// Classe para criar os personagens
class Personagem {
  constructor(x, y, nome, cor) {
    this.x = x;
    this.y = y;
    this.nome = nome;
    this.cor = cor;
    this.largura = 50;
    this.altura = 50;
  }

  show() {
    // Exibe o cubo (personagem) com a cor definida
    fill(this.cor);
    rect(this.x, this.y, this.largura, this.altura);

    // Exibe o nome do personagem
    fill(0);
    textSize(16);
    text(this.nome, this.x, this.y - 10);
  }
}
